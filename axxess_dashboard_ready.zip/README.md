# Axxess Sales Dashboard — Ready-to-deploy bundle

## Contents
- index.html — Login / landing
- agent.html — Agent dashboard
- manager.html — Manager dashboard (add + monitor agents, live Supabase sync)
- tv.html — TV display view (auto-refreshes, read-only)
- styles.css — Clean layout and consistent theme
- supabase-config.js — Configured with your Supabase URL + anon key
- vercel.json — Ensures Vercel runs the API endpoints properly
- .env.local.sample — Sample environment file for server secrets
- README.md — This file

/api
- add-agent.js — Inserts new agent (creates Auth user via service role key, inserts into `agents`)
- create-user.js — optional helper endpoint
- reset-password.js — updates user's password via Admin API

## Deploy
1. Copy `.env.local.sample` to `.env.local` (or add environment variables in Vercel) and set `SUPABASE_SERVICE_ROLE_KEY`.
2. Deploy this repo to Vercel (link to GitHub) — serverless functions live under `/api/*`.
3. Manager login email is `stephanie@internet.co.za`. Use real passwords when creating agents.

**Security note:** Per your request this project stores plaintext passwords in the `agents` table. This is insecure in production. Keep the Service Role key secret (do not commit it to GitHub).

